 /**

* 

* @author Encore

* @Time 2016/3/19

*

*/

import java.util.Vector;

public interface SendMessage {
	public void StoreStuInfo(Vector<String> info);
}
